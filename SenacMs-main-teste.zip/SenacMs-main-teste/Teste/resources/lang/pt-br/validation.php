<?php

return [

   'required' => 'Este campo é obrigatório',
   'unique' => 'Este valor já existe',
   'email' => 'Digite um e-mail válido',
];




<div class="p-5">

    <img  class="flex absolute top-3 left-0" src="{{asset('image/Frame 80.png')}}" alt="">

    
    <header class="flex relative items-center  rounded-2xl  bg-white justify-between w-full">
        <img class="h-25"  src="{{asset('image/Logo - Isotipo Cor.png')}}" alt="">
        <ul class="flex w-full gap-10 justify-center items-center">

            <li>
                <a href="" class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-calendar"></i>Eventos</a>
            </li>
            <li>
                <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-ticket"></i>Ingressos</a>
            </li>
            <li>
                <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-users"></i>Usuários</a>
            </li>
            <li>
                <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-qrcode"></i>Validador</a>
            </li>
            <li>
                <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-receipt"></i>Venda</a>
            </li>
            <li>
                <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600 items-center"><i class="fa-solid fa-grip"></i>Dashboard</a>
            </li>
        </ul>
        <li class="flex ">
            <a href=""  class="flex gap-2 BtnHover p-1 rounded-2xl text-gray-600  items-center"><i class="fa-solid fa-right-from-bracket"></i>Sair</a>
        </li>
    </header>

</div>